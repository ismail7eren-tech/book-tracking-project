import React, { useState } from 'react';

const API = "/api";
const initialBook = { title: "", author: "", totalPages: "", currentPage: "", topicNames: "" };

export default function Forms({ books, readingBooks, fetchDashboard, token }) {
  const [bookForm, setBookForm] = useState(initialBook);
  const [sessionForm, setSessionForm] = useState({
    bookId: "", date: new Date().toISOString(), pagesRead: "", fromPage: "", toPage: "", notes: ""
  });
  const [insightForm, setInsightForm] = useState({
    bookId: "", content: "", learnedAt: new Date().toISOString()
  });

  async function createBook(e) {
    e.preventDefault();
    const payload = {
      ...bookForm,
      totalPages: Number(bookForm.totalPages),
      currentPage: Number(bookForm.currentPage || 0),
      topicNames: bookForm.topicNames.split(",").map(t => t.trim()).filter(Boolean),
      startedAt: new Date().toISOString(),
    };

    const res = await fetch(`${API}/books`, {
      method: "POST", headers: { "Content-Type": "application/json", "Authorization": `Bearer ${token}` }, body: JSON.stringify(payload)
    });

    if (res.ok) {
      setBookForm(initialBook);
      await fetchDashboard();
    }
  }

  async function addSession(e) {
    e.preventDefault();
    const res = await fetch(`${API}/sessions`, {
      method: "POST", headers: { "Content-Type": "application/json", "Authorization": `Bearer ${token}` },
      body: JSON.stringify({
        ...sessionForm,
        bookId: Number(sessionForm.bookId),
        pagesRead: Number(sessionForm.pagesRead),
        fromPage: sessionForm.fromPage ? Number(sessionForm.fromPage) : undefined,
        toPage: sessionForm.toPage ? Number(sessionForm.toPage) : undefined,
      }),
    });

    if (res.ok) {
      setSessionForm({
        bookId: "", date: new Date().toISOString(), pagesRead: "", fromPage: "", toPage: "", notes: ""
      });
      await fetchDashboard();
    }
  }

  async function addInsight(e) {
    e.preventDefault();
    const res = await fetch(`${API}/insights`, {
      method: "POST", headers: { "Content-Type": "application/json", "Authorization": `Bearer ${token}` },
      body: JSON.stringify({ ...insightForm, bookId: Number(insightForm.bookId) }),
    });

    if (res.ok) {
      setInsightForm({ bookId: "", content: "", learnedAt: new Date().toISOString() });
      await fetchDashboard();
    }
  }

  return (
    <section className="grid forms">
      <form onSubmit={createBook} className="glass-panel">
        <h2>Yeni Kitap Ekle</h2>
        <input placeholder="Kitap adı" value={bookForm.title} onChange={e => setBookForm(p => ({ ...p, title: e.target.value }))} required />
        <input placeholder="Yazar" value={bookForm.author} onChange={e => setBookForm(p => ({ ...p, author: e.target.value }))} required />
        <input type="number" placeholder="Toplam sayfa" value={bookForm.totalPages} onChange={e => setBookForm(p => ({ ...p, totalPages: e.target.value }))} required />
        <input type="number" placeholder="Şu anki sayfa" value={bookForm.currentPage} onChange={e => setBookForm(p => ({ ...p, currentPage: e.target.value }))} />
        <input placeholder="Konular (virgülle ayır)" value={bookForm.topicNames} onChange={e => setBookForm(p => ({ ...p, topicNames: e.target.value }))} />
        <button type="submit">Kitabı Kaydet</button>
      </form>

      <form onSubmit={addSession} className="glass-panel">
        <h2>Günlük Okuma Gir</h2>
        <select value={sessionForm.bookId} onChange={e => setSessionForm(p => ({ ...p, bookId: e.target.value }))} required>
          <option value="">Kitap seç</option>
          {readingBooks.map(b => <option key={b.id} value={b.id}>{b.title}</option>)}
        </select>
        <input type="datetime-local" value={sessionForm.date.slice(0, 16)} onChange={e => setSessionForm(p => ({ ...p, date: new Date(e.target.value).toISOString() }))} required />
        <input type="number" placeholder="Okunan sayfa" value={sessionForm.pagesRead} onChange={e => setSessionForm(p => ({ ...p, pagesRead: e.target.value }))} required />
        <input type="number" placeholder="Başlangıç sayfa" value={sessionForm.fromPage} onChange={e => setSessionForm(p => ({ ...p, fromPage: e.target.value }))} />
        <input type="number" placeholder="Bitiş sayfa" value={sessionForm.toPage} onChange={e => setSessionForm(p => ({ ...p, toPage: e.target.value }))} />
        <textarea placeholder="Not (opsiyonel)" value={sessionForm.notes} onChange={e => setSessionForm(p => ({ ...p, notes: e.target.value }))} />
        <button type="submit">Okumayı Ekle</button>
      </form>

      <form onSubmit={addInsight} className="glass-panel">
        <h2>Kitaptan Öğrendiklerim</h2>
        <select value={insightForm.bookId} onChange={e => setInsightForm(p => ({ ...p, bookId: e.target.value }))} required>
          <option value="">Kitap seç</option>
          {books.map(b => <option key={b.id} value={b.id}>{b.title}</option>)}
        </select>
        <textarea placeholder="Bu kitaptan ne öğrendin?" value={insightForm.content} onChange={e => setInsightForm(p => ({ ...p, content: e.target.value }))} required />
        <button type="submit">Öğrenimi Kaydet</button>
      </form>
    </section>
  );
}
