import { useEffect, useState, useMemo } from "react";
import "./App.css";

import DashboardStats from "./components/DashboardStats";
import Forms from "./components/Forms";
import BookList from "./components/BookList";
import MonthlyChart from "./components/MonthlyChart";
import Login from "./components/Login";

const API = "/api";

function App() {
  const [token, setToken] = useState(localStorage.getItem("token") || "");
  const [user, setUser] = useState(localStorage.getItem("user") || "");
  const [books, setBooks] = useState([]);
  const [stats, setStats] = useState(null);
  const [monthlyPages, setMonthlyPages] = useState([]);
  const [error, setError] = useState("");

  const readingBooks = useMemo(() => books.filter((b) => b.status === "READING"), [books]);

  async function fetchDashboard() {
    if (!token) return;
    try {
      setError("");
      const headers = { Authorization: `Bearer ${token}` };
      const [booksRes, statsRes, monthlyRes] = await Promise.all([
        fetch(`${API}/books`, { headers }),
        fetch(`${API}/stats/overview`, { headers }),
        fetch(`${API}/stats/monthly-pages`, { headers }),
      ]);

      if (booksRes.status === 401 || statsRes.status === 401) {
        handleLogout();
        throw new Error("Oturum süresi doldu, lütfen tekrar giriş yapın.");
      }

      if (!booksRes.ok || !statsRes.ok || !monthlyRes.ok) throw new Error("Veri alınamadı");

      const booksData = await booksRes.json();
      const statsData = await statsRes.json();
      const monthlyData = await monthlyRes.json();
      
      setBooks(booksData);
      setStats(statsData);
      setMonthlyPages(monthlyData);
    } catch (err) {
      if (err.message) {
        setError(err.message);
      } else {
        setError("Backend'e bağlanılamadı. Sunucuyu kontrol edin.");
      }
    }
  }

  useEffect(() => {
    fetchDashboard();
  }, [token]);

  function handleLogout() {
    setToken("");
    setUser("");
    localStorage.removeItem("token");
    localStorage.removeItem("user");
  }

  if (!token) {
    return (
      <div className="container">
        <header>
          <h1>Kitap Takipi</h1>
          <p>Devam etmek için giriş yapın veya kayıt olun.</p>
        </header>
        <Login setToken={setToken} setUser={setUser} />
      </div>
    );
  }

  return (
    <div className="container">
      <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ textAlign: 'left' }}>
          <h1>Kitap Takip Paneli</h1>
          <p>Hoş geldin, <strong>{user}</strong>. Nerede kaldığını ve yıllık hedeflerini tek yerden yönet.</p>
        </div>
        <button onClick={handleLogout} className="danger" style={{ height: 'fit-content' }}>
          Çıkış Yap
        </button>
      </header>

      {error && <div className="error">{error}</div>}

      <DashboardStats stats={stats} />
      
      <Forms books={books} readingBooks={readingBooks} fetchDashboard={fetchDashboard} token={token} />
      
      <BookList books={books} stats={stats} fetchDashboard={fetchDashboard} token={token} />
      
      <MonthlyChart monthlyPages={monthlyPages} />
    </div>
  );
}

export default App;
